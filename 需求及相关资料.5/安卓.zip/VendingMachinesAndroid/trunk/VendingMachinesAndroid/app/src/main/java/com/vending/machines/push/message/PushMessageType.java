package com.vending.machines.push.message;

public enum PushMessageType {
    PAY_SUCCESS;
}
