/** Automatically generated file. DO NOT MODIFY */
package com.vending.machines;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}