package org.myframe.utils;

import android.content.Context;

public class MContext {
	public static Context CONTEXT = null;
}
