package com.coreservice;

import org.myframe.ui.BindLayout;

import android.app.Activity;
import android.os.Bundle;

public class MainAct extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		finish();
	}
}
