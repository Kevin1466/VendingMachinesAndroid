package com.coreservice;

public interface OnDownloadRet {
	void onResponse(boolean flag);
}
